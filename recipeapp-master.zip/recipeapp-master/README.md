# RecipeApp

Recipe App UI template using Flutter.

Inspiration from [this awesome dribbble](https://dribbble.com/shots/5299031-Recipe-Sharing-Food-Channel). 

![](recipedemo.gif)

Recipes used for template taken from [Delish](https://www.delish.com/).
